module.exports = {
    reactStrictMode: true,
    images: {
      domains: ['unicodewebdesign.com','avatar.iran.liara.run','trustseal.enamad.ir','www.paydarweb.net'],
    },
  }